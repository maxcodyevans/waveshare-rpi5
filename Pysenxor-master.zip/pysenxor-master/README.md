PySenXor is a Python library for interacting with Meridian Innovation’s camera
modules and thermal imaging processors.

PySenXor aims to bring you a great thermal imaging stream out of the box
with a few lines of code, and enable you to focus on the processing
and analytics of the thermal data for the application you're trying to
enhance by adding thermal imaging.

See docs directory for details.

Installation (assuming you are in a virtual environment and in the root of pysenxor):

pip install -e ./

